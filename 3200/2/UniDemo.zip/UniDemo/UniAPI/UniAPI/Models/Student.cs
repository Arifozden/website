﻿namespace UniAPI.Models
{
    public class Student
    {
        public Guid Id { get; set; }
        public string Name { get; set; }
        public string Surname { get; set; }
        public string studNumber { get; set; }
        public string email { get; set; }
        public string mobil { get; set; }
        public string courseName { get; set; }
        public string beginYear { get; set; }
    }
}