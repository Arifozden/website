export interface Student {
    id:string,
    name:string,
    surname:string,
    studNumber:string,
    email:string,
    mobil:string,
    courseName:string,
    beginYear:string
}